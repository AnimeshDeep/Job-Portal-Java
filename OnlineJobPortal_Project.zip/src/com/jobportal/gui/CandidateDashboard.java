package com.jobportal.gui;

import com.jobportal.dao.JobDAO;
import com.jobportal.dao.impl.JobDAOImpl;
import com.jobportal.model.Job;
import com.jobportal.model.User;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class CandidateDashboard extends JFrame {

    private User candidate;
    private JobDAO jobDAO = new JobDAOImpl();
    private JList<Job> jobList;

    public CandidateDashboard(User candidate) {
        this.candidate = candidate;

        setTitle("Candidate Dashboard - " + candidate.getName());
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        List<Job> jobs = jobDAO.getAllJobs();
        jobList = new JList<>(jobs.toArray(new Job[0]));

        add(new JScrollPane(jobList), BorderLayout.CENTER);
        JLabel label = new JLabel("Available Jobs");
        label.setHorizontalAlignment(SwingConstants.CENTER);
        add(label, BorderLayout.NORTH);
    }
}
