package com.jobportal.gui;

import com.jobportal.dao.UserDAO;
import com.jobportal.dao.impl.UserDAOImpl;
import com.jobportal.model.User;

import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {

    private JTextField emailField;
    private JPasswordField passwordField;
    private JComboBox<String> roleBox;
    private UserDAO userDAO = new UserDAOImpl();

    public LoginFrame() {
        setTitle("Online Job Portal - Login");
        setSize(400, 280);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        panel.add(new JLabel("Email:"));
        emailField = new JTextField();
        panel.add(emailField);

        panel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        panel.add(passwordField);

        panel.add(new JLabel("Role:"));
        roleBox = new JComboBox<>(new String[]{"ADMIN", "EMPLOYER", "CANDIDATE"});
        panel.add(roleBox);

        JButton loginBtn = new JButton("Login");
        loginBtn.addActionListener(e -> doLogin());
        panel.add(new JLabel());
        panel.add(loginBtn);

        add(panel, BorderLayout.CENTER);
    }

    private void doLogin() {
        String email = emailField.getText();
        String pwd = new String(passwordField.getPassword());
        String selectedRole = roleBox.getSelectedItem().toString();

        User user = userDAO.login(email, pwd);

        if (user != null && user.getRole().equals(selectedRole)) {
            JOptionPane.showMessageDialog(this, "Login successful as " + selectedRole);
            dispose();
            switch (selectedRole) {
                case "CANDIDATE":
                    new CandidateDashboard(user).setVisible(true);
                    break;
                case "EMPLOYER":
                    new EmployerDashboard(user).setVisible(true);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Admin logged in (no dashboard demo).");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Invalid credentials or role mismatch");
        }
    }
}
