package com.jobportal.gui;

import com.jobportal.dao.JobDAO;
import com.jobportal.dao.impl.JobDAOImpl;
import com.jobportal.model.Job;
import com.jobportal.model.User;

import javax.swing.*;
import java.awt.*;

public class EmployerDashboard extends JFrame {

    private User employer;
    private JobDAO jobDAO = new JobDAOImpl();

    private JTextField titleField;
    private JTextField companyField;
    private JTextField salaryField;
    private JTextArea descArea;

    public EmployerDashboard(User employer) {
        this.employer = employer;

        setTitle("Employer Dashboard - " + employer.getName());
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel form = new JPanel(new GridLayout(5, 2, 10, 10));
        form.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        form.add(new JLabel("Job Title:"));
        titleField = new JTextField();
        form.add(titleField);

        form.add(new JLabel("Company:"));
        companyField = new JTextField();
        form.add(companyField);

        form.add(new JLabel("Salary:"));
        salaryField = new JTextField();
        form.add(salaryField);

        form.add(new JLabel("Description:"));
        descArea = new JTextArea(3, 20);
        form.add(new JScrollPane(descArea));

        JButton addBtn = new JButton("Post Job");
        addBtn.addActionListener(e -> addJob());
        form.add(new JLabel());
        form.add(addBtn);

        add(form, BorderLayout.CENTER);
    }

    private void addJob() {
        try {
            String title = titleField.getText();
            String company = companyField.getText();
            double salary = Double.parseDouble(salaryField.getText());
            String desc = descArea.getText();

            Job job = new Job();
            job.setTitle(title);
            job.setCompany(company);
            job.setSalary(salary);
            job.setDescription(desc);
            job.setEmployerId(employer.getUserId());

            boolean ok = jobDAO.addJob(job);
            if (ok) {
                JOptionPane.showMessageDialog(this, "Job posted successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to post job");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid salary");
        }
    }
}
