package com.jobportal.dao;

import java.util.List;
import com.jobportal.model.Application;

public interface ApplicationDAO {
    boolean apply(Application application);
    List<Application> getApplicationsByJob(int jobId);
    List<Application> getApplicationsByCandidate(int candidateId);
}
