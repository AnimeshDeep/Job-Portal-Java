package com.jobportal.dao.impl;

import com.jobportal.dao.UserDAO;
import com.jobportal.model.Admin;
import com.jobportal.model.Candidate;
import com.jobportal.model.Employer;
import com.jobportal.model.User;
import com.jobportal.util.DBConnection;

import java.sql.*;

public class UserDAOImpl implements UserDAO {

    @Override
    public User login(String email, String password) {
        String sql = "SELECT * FROM users WHERE email = ? AND password = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int userId = rs.getInt("user_id");
                    String name = rs.getString("name");
                    String role = rs.getString("role");

                    switch (role) {
                        case "ADMIN":
                            return new Admin(userId, name, email, password);
                        case "EMPLOYER":
                            Employer emp = new Employer();
                            emp.setUserId(userId);
                            emp.setName(name);
                            emp.setEmail(email);
                            emp.setPassword(password);
                            emp.setRole("EMPLOYER");
                            return emp;
                        case "CANDIDATE":
                            return new Candidate(userId, name, email, password);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean register(User user) {
        String sql = "INSERT INTO users(name, email, password, role) VALUES(?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, user.getName());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPassword());
            ps.setString(4, user.getRole());

            int rows = ps.executeUpdate();
            return rows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
