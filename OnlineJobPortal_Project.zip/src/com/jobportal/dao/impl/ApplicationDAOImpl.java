package com.jobportal.dao.impl;

import com.jobportal.dao.ApplicationDAO;
import com.jobportal.model.Application;
import com.jobportal.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ApplicationDAOImpl implements ApplicationDAO {

    @Override
    public boolean apply(Application application) {
        String sql = "INSERT INTO applications(job_id, candidate_id, status) VALUES(?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, application.getJobId());
            ps.setInt(2, application.getCandidateId());
            ps.setString(3, application.getStatus());

            int rows = ps.executeUpdate();
            return rows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public List<Application> getApplicationsByJob(int jobId) {
        List<Application> list = new ArrayList<>();
        String sql = "SELECT * FROM applications WHERE job_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, jobId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Application app = new Application(
                            rs.getInt("app_id"),
                            rs.getInt("job_id"),
                            rs.getInt("candidate_id"),
                            rs.getString("status")
                    );
                    list.add(app);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<Application> getApplicationsByCandidate(int candidateId) {
        List<Application> list = new ArrayList<>();
        String sql = "SELECT * FROM applications WHERE candidate_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, candidateId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Application app = new Application(
                            rs.getInt("app_id"),
                            rs.getInt("job_id"),
                            rs.getInt("candidate_id"),
                            rs.getString("status")
                    );
                    list.add(app);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
