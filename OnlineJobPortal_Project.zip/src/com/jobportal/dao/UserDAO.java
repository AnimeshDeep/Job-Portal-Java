package com.jobportal.dao;

import com.jobportal.model.User;

public interface UserDAO {
    User login(String email, String password);
    boolean register(User user);
}
