package com.jobportal.dao;

import java.util.List;
import com.jobportal.model.Job;

public interface JobDAO {
    boolean addJob(Job job);
    List<Job> getAllJobs();
    List<Job> getJobsByEmployer(int employerId);
}
