package com.jobportal.model;

public class Candidate extends User {

    public Candidate() {
        this.role = "CANDIDATE";
    }

    public Candidate(int userId, String name, String email, String password) {
        super(userId, name, email, password, "CANDIDATE");
    }
}
