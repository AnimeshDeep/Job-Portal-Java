package com.jobportal.model;

public class Admin extends User {

    public Admin() {
        this.role = "ADMIN";
    }

    public Admin(int userId, String name, String email, String password) {
        super(userId, name, email, password, "ADMIN");
    }
}
