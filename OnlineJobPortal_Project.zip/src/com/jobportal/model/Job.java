package com.jobportal.model;

public class Job {
    private int jobId;
    private String title;
    private String description;
    private String company;
    private double salary;
    private int employerId;

    public Job() {}

    public Job(int jobId, String title, String description, String company, double salary, int employerId) {
        this.jobId = jobId;
        this.title = title;
        this.description = description;
        this.company = company;
        this.salary = salary;
        this.employerId = employerId;
    }

    public int getJobId() { return jobId; }
    public void setJobId(int jobId) { this.jobId = jobId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getCompany() { return company; }
    public void setCompany(String company) { this.company = company; }

    public double getSalary() { return salary; }
    public void setSalary(double salary) { this.salary = salary; }

    public int getEmployerId() { return employerId; }
    public void setEmployerId(int employerId) { this.employerId = employerId; }

    @Override
    public String toString() {
        return jobId + " - " + title + " (" + company + ")";
    }
}
