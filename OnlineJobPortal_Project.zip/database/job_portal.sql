CREATE DATABASE IF NOT EXISTS job_portal;
USE job_portal;

CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    role ENUM('ADMIN','EMPLOYER','CANDIDATE') NOT NULL
);

CREATE TABLE IF NOT EXISTS jobs (
    job_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    company VARCHAR(150),
    salary DECIMAL(10,2),
    employer_id INT,
    FOREIGN KEY (employer_id) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS applications (
    app_id INT AUTO_INCREMENT PRIMARY KEY,
    job_id INT,
    candidate_id INT,
    status VARCHAR(50) DEFAULT 'APPLIED',
    FOREIGN KEY (job_id) REFERENCES jobs(job_id),
    FOREIGN KEY (candidate_id) REFERENCES users(user_id)
);

INSERT INTO users (name, email, password, role)
VALUES ('Admin User', 'admin@portal.com', 'admin123', 'ADMIN');

INSERT INTO users (name, email, password, role)
VALUES ('ABC Pvt Ltd HR', 'hr@abc.com', 'hr123', 'EMPLOYER');

INSERT INTO users (name, email, password, role)
VALUES ('Rupesh Kumar', 'rupesh@example.com', 'rupesh123', 'CANDIDATE');
